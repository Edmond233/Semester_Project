#include <iostream>
#include <vector>
#include <string>
#include <map>

using namespace std;

class Patient {
public:
    string name;
    int age;
    string diagnosis;

    Patient(string n, int a, string d) : name(n), age(a), diagnosis(d) {}
};

class Appointment {
public:
    string doctorName;
    string patientName;
    string date;

    Appointment(string doc, string pat, string dt) : doctorName(doc), patientName(pat), date(dt) {}
};

class Bill {
public:
    string patientName;
    double amount;

    Bill(string pat, double amt) : patientName(pat), amount(amt) {}
};

class Hospital {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;
    vector<Bill> bills;
    map<string, string> userCredentials; // username -> password

public:
    Hospital() {
        // Pre-populate user credentials (demo purposes)
        userCredentials["admin"] = "password";
    }

    void registerUser(string username, string password) {
        userCredentials[username] = password;
        cout << "User registered successfully." << endl;
    }

    bool authenticateUser(string username, string password) {
        if (userCredentials.find(username) != userCredentials.end() && userCredentials[username] == password) {
            return true;
        }
        return false;
    }

    void addPatient(string name, int age, string diagnosis) {
        patients.push_back(Patient(name, age, diagnosis));
        cout << "Patient added successfully." << endl;
    }

    void addAppointment(string doctorName, string patientName, string date) {
        appointments.push_back(Appointment(doctorName, patientName, date));
        cout << "Appointment scheduled successfully." << endl;
    }

    void addBill(string patientName, double amount) {
        bills.push_back(Bill(patientName, amount));
        cout << "Bill added successfully." << endl;
    }

    void viewPatients() {
        cout << "Patient List:" << endl;
        for (const Patient &patient : patients) {
            cout << "Name: " << patient.name << "\tAge: " << patient.age << "\tDiagnosis: " << patient.diagnosis << endl;
        }
    }

    void viewAppointments() {
        cout << "Appointment List:" << endl;
        for (const Appointment &appointment : appointments) {
            cout << "Doctor: " << appointment.doctorName << "\tPatient: " << appointment.patientName << "\tDate: " << appointment.date << endl;
        }
    }

    void viewBills() {
        cout << "Bill List:" << endl;
        for (const Bill &bill : bills) {
            cout << "Patient: " << bill.patientName << "\tAmount: " << bill.amount << endl;
        }
    }
};

int main() {
    Hospital hospital;

    while (true) {
        cout << "Hospital Management System" << endl;
        cout << "1. Register User" << endl;
        cout << "2. Authenticate User" << endl;
        cout << "3. Add Patient" << endl;
        cout << "4. View Patients" << endl;
        cout << "5. Add Appointment" << endl;
        cout << "6. View Appointments" << endl;
        cout << "7. Add Bill" << endl;
        cout << "8. View Bills" << endl;
        cout << "9. Exit" << endl;

        int choice;
        cin >> choice;

        switch (choice) {
            case 1: {
                string username, password;
                cout << "Enter username: ";
                cin >> username;
                cout << "Enter password: ";
                cin >> password;
                hospital.registerUser(username, password);
                break;
            }
            case 2: {
                string username, password;
                cout << "Enter username: ";
                cin >> username;
                cout << "Enter password: ";
                cin >> password;
                if (hospital.authenticateUser(username, password)) {
                    cout << "Authentication successful." << endl;
                } else {
                    cout << "Authentication failed." << endl;
                }
                break;
            }
            case 3: {
                string name, diagnosis;
                int age;

                cout << "Enter patient name: ";
                cin.ignore();
                getline(cin, name);

                cout << "Enter patient age: ";
                cin >> age;

                cout << "Enter diagnosis: ";
                cin.ignore();
                getline(cin, diagnosis);

                hospital.addPatient(name, age, diagnosis);
                break;
            }
            case 4:
                hospital.viewPatients();
                break;
            case 5: {
                string doctorName, patientName, date;

                cout << "Enter doctor's name: ";
                cin.ignore();
                getline(cin, doctorName);

                cout << "Enter patient's name: ";
                getline(cin, patientName);

                cout << "Enter appointment date: ";
                getline(cin, date);

                hospital.addAppointment(doctorName, patientName, date);
                break;
            }
            case 6:
                hospital.viewAppointments();
                break;
            case 7: {
                string patientName;
                double amount;

                cout << "Enter patient's name: ";
                cin.ignore();
                getline(cin, patientName);

                cout << "Enter bill amount: ";
                cin >> amount;

                hospital.addBill(patientName, amount);
                break;
            }
            case 8:
                hospital.viewBills();
                break;
            case 9:
                cout << "Exiting the program." << endl;
                return 0;
            default:
                cout << "Invalid choice. Please select a valid option." << endl;
                break;
        }
    }

    return 0;
}
